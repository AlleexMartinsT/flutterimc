# IMC 
### Aplicativo para calcular IMC

122100025 - Hiago Ferreira dos Santos
122100007 - Matheus Matos Rodrigues

<img src="imagens/magreza.png" width="350" height="400">
<img src="imagens/pesoIdeal.png" width="350" height="400">

</br>

<img src="imagens/sobrepeso.png" width="350" height="400">
<img src="imagens/obesidade1.png" width="350" height="400">

</br>

<img src="imagens/obesidade2.png" width="350" height="400">
<img src="imagens/obesidade3.png" width="350" height="400">
