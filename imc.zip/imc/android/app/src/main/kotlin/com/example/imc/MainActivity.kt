package com.example.imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
